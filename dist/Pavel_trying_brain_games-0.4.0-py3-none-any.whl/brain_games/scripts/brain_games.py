def main():
    print('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()

import sys
sys.path.append("/home/pavel/python-project-lvl1/brain_games")

from cli import welcome_user
welcome_user()


